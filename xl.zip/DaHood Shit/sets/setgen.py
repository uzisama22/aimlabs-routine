import random, threading
numbers = "0123456789"
digitszz = 4
def yes():
    while True:
        gen = "".join(random.sample(numbers, digitszz))
        print(str("0.1" + gen))

for x in range(1000):
    thread = threading.Thread(target=yes).start()