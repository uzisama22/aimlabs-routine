getgenv().Block_Webhooks = true
loadstring(game:HttpGet("https://raw.githubusercontent.com/Vanis252/HTTPSPY/main/script"))()